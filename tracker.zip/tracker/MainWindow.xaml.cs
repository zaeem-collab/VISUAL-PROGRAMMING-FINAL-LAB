﻿using System;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace tracker
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Student> Students { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            Students = new ObservableCollection<Student>();
            StudentDataGrid.ItemsSource = Students;

            LoadStudentsFromDatabase();
        }

        private void LoadStudentsFromDatabase()
        {
            string connectionString = "Data Source=CHAUDHRY-ZAEEM;Initial Catalog=tracker;Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM student";
                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Students.Add(new Student
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            Name = reader["Name"].ToString(),
                            Grade = reader["Grade"].ToString(),
                            Subject = reader["Subject"].ToString(),
                            Marks = Convert.ToInt32(reader["Marks"]),
                            AttendancePercentage = Convert.ToDouble(reader["AttendancePercentage"])
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading students: {ex.Message}");
            }
        }

        private void GradeFilterComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            string selectedGrade = (GradeFilterComboBox.SelectedItem as System.Windows.Controls.ComboBoxItem)?.Content.ToString();
            if (selectedGrade == "All")
            {
                StudentDataGrid.ItemsSource = Students;
            }
            else
            {
                StudentDataGrid.ItemsSource = new ObservableCollection<Student>(Students.Where(s => s.Grade == selectedGrade));
            }
        }

        // Add Student Button Click
        private void AddStudentButton_Click(object sender, RoutedEventArgs e)
        {
            // Example data for adding a new student
            var newStudent = new Student
            {
                Name = "New Student",
                Grade = "A",
                Subject = "Physics",
                Marks = 90,
                AttendancePercentage = 95.0
            };

            // Add student to ObservableCollection and Database
            Students.Add(newStudent);
            AddStudentToDatabase(newStudent);
        }

        // Edit Student Button Click
        private void EditStudentButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = StudentDataGrid.SelectedItem as Student;
            if (selectedStudent != null)
            {
                // Edit selected student
                selectedStudent.Name = "Updated Name"; // Example edit
                selectedStudent.Marks = 100; // Example edit
                EditStudentInDatabase(selectedStudent);
            }
            else
            {
                MessageBox.Show("Please select a student to edit.");
            }
        }

        // Delete Student Button Click
        private void DeleteStudentButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedStudent = StudentDataGrid.SelectedItem as Student;
            if (selectedStudent != null)
            {
                Students.Remove(selectedStudent);
                DeleteStudentFromDatabase(selectedStudent);
            }
            else
            {
                MessageBox.Show("Please select a student to delete.");
            }
        }

        private void AddStudentToDatabase(Student student)
        {
            string connectionString = "Data Source=CHAUDHRY-ZAEEM;Initial Catalog=tracker;Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO student (Name, Grade, Subject, Marks, AttendancePercentage) " +
                                   "VALUES (@Name, @Grade, @Subject, @Marks, @AttendancePercentage)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Name", student.Name);
                    command.Parameters.AddWithValue("@Grade", student.Grade);
                    command.Parameters.AddWithValue("@Subject", student.Subject);
                    command.Parameters.AddWithValue("@Marks", student.Marks);
                    command.Parameters.AddWithValue("@AttendancePercentage", student.AttendancePercentage);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding student: {ex.Message}");
            }
        }

        private void EditStudentInDatabase(Student student)
        {
            string connectionString = "Data Source=CHAUDHRY-ZAEEM;Initial Catalog=tracker;Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE student SET Name = @Name, Grade = @Grade, Subject = @Subject, " +
                                   "Marks = @Marks, AttendancePercentage = @AttendancePercentage WHERE Id = @Id";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", student.Id);
                    command.Parameters.AddWithValue("@Name", student.Name);
                    command.Parameters.AddWithValue("@Grade", student.Grade);
                    command.Parameters.AddWithValue("@Subject", student.Subject);
                    command.Parameters.AddWithValue("@Marks", student.Marks);
                    command.Parameters.AddWithValue("@AttendancePercentage", student.AttendancePercentage);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error editing student: {ex.Message}");
            }
        }

        private void DeleteStudentFromDatabase(Student student)
        {
            string connectionString = "Data Source=CHAUDHRY-ZAEEM;Initial Catalog=tracker;Integrated Security=True;Trust Server Certificate=True";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "DELETE FROM student WHERE Id = @Id";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Id", student.Id);

                    command.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting student: {ex.Message}");
            }
        }

        private void StudentDataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Logic for handling selection change, if needed
        }
    }

    public class Student
    {
        public int Id { get; set; } // Added Id for SQL handling
        public string Name { get; set; }
        public string Grade { get; set; }
        public string Subject { get; set; }
        public int Marks { get; set; }
        public double AttendancePercentage { get; set; }
    }
}
